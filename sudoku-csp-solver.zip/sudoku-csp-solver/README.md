# AI-Based Sudoku Solver Using CSP Techniques

A browser-based Sudoku solver built with HTML, CSS, and JavaScript.

## Features
- Interactive 9×9 Sudoku grid
- Example puzzle and clear-grid controls
- Validates conflicting clues
- CSP-style candidate generation (constraint propagation)
- Recursive backtracking search
- Minimum Remaining Values (MRV) heuristic
- Reports elapsed time, search nodes, and backtracks
- Responsive layout for mobile and desktop

## Run locally
Open `index.html` in a web browser.

## Publish using GitHub Pages
1. Create a public GitHub repository named `sudoku-csp-solver`.
2. Upload `index.html`, `style.css`, and `script.js` to the repository root.
3. Open **Settings → Pages**.
4. Under Build and deployment, select **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. Wait for GitHub Pages to publish the site. The URL will appear in the Pages section.

This is a front-end demonstration; no server or API key is needed.
