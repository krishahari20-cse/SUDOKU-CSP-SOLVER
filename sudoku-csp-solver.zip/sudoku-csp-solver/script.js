const gridElement = document.getElementById("sudoku-grid");
const statusElement = document.getElementById("status");
const solveButton = document.getElementById("solve-btn");
const exampleButton = document.getElementById("example-btn");
const clearButton = document.getElementById("clear-btn");

const examplePuzzle = [
  [5,3,0,0,7,0,0,0,0],
  [6,0,0,1,9,5,0,0,0],
  [0,9,8,0,0,0,0,6,0],
  [8,0,0,0,6,0,0,0,3],
  [4,0,0,8,0,3,0,0,1],
  [7,0,0,0,2,0,0,0,6],
  [0,6,0,0,0,0,2,8,0],
  [0,0,0,4,1,9,0,0,5],
  [0,0,0,0,8,0,0,7,9]
];

function createGrid() {
  gridElement.innerHTML = "";
  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      const input = document.createElement("input");
      input.className = "sudoku-cell";
      input.type = "text";
      input.inputMode = "numeric";
      input.maxLength = 1;
      input.setAttribute("aria-label", `Row ${row + 1}, column ${col + 1}`);
      input.dataset.row = row;
      input.dataset.col = col;
      input.addEventListener("input", () => {
        input.value = input.value.replace(/[^1-9]/g, "").slice(0, 1);
        input.classList.remove("invalid", "solved");
        input.classList.remove("given");
        setStatus("Puzzle edited. Click Solve Puzzle when ready.");
      });
      gridElement.appendChild(input);
    }
  }
}

function readGrid() {
  const board = Array.from({ length: 9 }, () => Array(9).fill(0));
  [...gridElement.children].forEach(input => {
    board[Number(input.dataset.row)][Number(input.dataset.col)] = Number(input.value) || 0;
  });
  return board;
}

function displayGrid(board, original = null) {
  [...gridElement.children].forEach(input => {
    const row = Number(input.dataset.row);
    const col = Number(input.dataset.col);
    input.value = board[row][col] || "";
    input.classList.remove("invalid", "given", "solved");
    if (board[row][col] && original && original[row][col]) input.classList.add("given");
    else if (board[row][col]) input.classList.add("solved");
  });
}

function setStatus(message, type = "") {
  statusElement.textContent = message;
  statusElement.className = `status ${type}`;
}

function candidates(board, row, col) {
  const used = new Set();
  for (let i = 0; i < 9; i++) {
    used.add(board[row][i]);
    used.add(board[i][col]);
  }
  const boxRow = Math.floor(row / 3) * 3;
  const boxCol = Math.floor(col / 3) * 3;
  for (let r = boxRow; r < boxRow + 3; r++) {
    for (let c = boxCol; c < boxCol + 3; c++) used.add(board[r][c]);
  }
  const values = [];
  for (let value = 1; value <= 9; value++) {
    if (!used.has(value)) values.push(value);
  }
  return values;
}

function hasDuplicateClues(board) {
  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      const value = board[row][col];
      if (!value) continue;
      board[row][col] = 0;
      const conflict = !candidates(board, row, col).includes(value);
      board[row][col] = value;
      if (conflict) return true;
    }
  }
  return false;
}

// CSP search: MRV chooses the empty cell with the smallest domain.
function solveCSP(board, stats) {
  let bestCell = null;
  let bestOptions = null;

  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      if (board[row][col] !== 0) continue;
      const options = candidates(board, row, col);
      if (options.length === 0) return false;
      if (bestOptions === null || options.length < bestOptions.length) {
        bestCell = [row, col];
        bestOptions = options;
        if (options.length === 1) break;
      }
    }
    if (bestOptions && bestOptions.length === 1) break;
  }

  if (bestCell === null) return true;

  const [row, col] = bestCell;
  for (const value of bestOptions) {
    stats.nodes++;
    board[row][col] = value;
    if (solveCSP(board, stats)) return true;
    board[row][col] = 0;
    stats.backtracks++;
  }
  return false;
}

function validateSolvedBoard(board) {
  const target = "123456789";
  for (let i = 0; i < 9; i++) {
    if ([...board[i]].sort().join("") !== target) return false;
    const column = board.map(row => row[i]).sort().join("");
    if (column !== target) return false;
  }
  for (let br = 0; br < 9; br += 3) {
    for (let bc = 0; bc < 9; bc += 3) {
      const values = [];
      for (let r = br; r < br + 3; r++)
        for (let c = bc; c < bc + 3; c++) values.push(board[r][c]);
      if (values.sort().join("") !== target) return false;
    }
  }
  return true;
}

solveButton.addEventListener("click", () => {
  const board = readGrid();
  const original = board.map(row => row.slice());

  if (hasDuplicateClues(board)) {
    setStatus("Invalid puzzle: a digit is repeated in a row, column, or 3 × 3 box.", "error");
    [...gridElement.children].forEach(input => input.classList.add("invalid"));
    return;
  }

  const stats = { nodes: 0, backtracks: 0 };
  const start = performance.now();
  const solved = solveCSP(board, stats);
  const elapsed = performance.now() - start;

  if (!solved || !validateSolvedBoard(board)) {
    setStatus(`No solution found. Search nodes: ${stats.nodes}. Check the puzzle clues.`, "error");
    return;
  }

  displayGrid(board, original);
  setStatus(`Solved successfully in ${elapsed.toFixed(2)} ms · Search nodes: ${stats.nodes} · Backtracks: ${stats.backtracks}`, "success");
});

exampleButton.addEventListener("click", () => {
  displayGrid(examplePuzzle);
  setStatus("Example puzzle loaded. Click Solve Puzzle to solve it.");
});

clearButton.addEventListener("click", () => {
  displayGrid(Array.from({ length: 9 }, () => Array(9).fill(0)));
  setStatus("Grid cleared. Enter a puzzle or load the example.");
});

createGrid();
displayGrid(examplePuzzle);
